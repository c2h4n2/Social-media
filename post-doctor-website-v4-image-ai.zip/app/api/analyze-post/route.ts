import { NextResponse } from "next/server";
import { analyzePost } from "@/lib/ai/analyzePost";

export const runtime = "nodejs";

const PLATFORMS = ["Instagram", "TikTok", "Facebook", "X", "LinkedIn", "Pinterest"];
const GOALS = ["More followers", "More views", "More comments", "Build my brand", "Sell something"];
const TONES = ["Casual", "Bold", "Professional", "Funny", "Inspirational", "Minimal"];

const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;

function validateSelections(platform: string, goal: string, tone: string) {
  return (
    PLATFORMS.includes(platform) &&
    GOALS.includes(goal) &&
    TONES.includes(tone)
  );
}

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") || "";

    let description = "";
    let platform = "";
    let goal = "";
    let tone = "";
    let imageDataUrl: string | undefined;

    if (contentType.includes("multipart/form-data")) {
      const form = await request.formData();

      description = String(form.get("description") || "").trim();
      platform = String(form.get("platform") || "");
      goal = String(form.get("goal") || "");
      tone = String(form.get("tone") || "");

      const image = form.get("image");

      if (image instanceof File && image.size > 0) {
        if (!ALLOWED_TYPES.has(image.type)) {
          return NextResponse.json(
            { error: "Please upload a JPG, PNG, or WEBP image." },
            { status: 400 }
          );
        }

        if (image.size > MAX_IMAGE_BYTES) {
          return NextResponse.json(
            { error: "Image is too large. Please use an image under 8 MB." },
            { status: 400 }
          );
        }

        const bytes = Buffer.from(await image.arrayBuffer());
        imageDataUrl = `data:${image.type};base64,${bytes.toString("base64")}`;
      }
    } else {
      const body = await request.json();

      description =
        typeof body.description === "string" ? body.description.trim() : "";
      platform = body.platform;
      goal = body.goal;
      tone = body.tone;
    }

    if (!validateSelections(platform, goal, tone)) {
      return NextResponse.json(
        { error: "Please check your platform, goal, and tone selections." },
        { status: 400 }
      );
    }

    if (!imageDataUrl && (description.length < 8 || description.length > 700)) {
      return NextResponse.json(
        { error: "Please add a short post description." },
        { status: 400 }
      );
    }

    if (description.length > 700) {
      return NextResponse.json(
        { error: "Description must be 700 characters or fewer." },
        { status: 400 }
      );
    }

    const report = await analyzePost({
      description: description || undefined,
      imageDataUrl,
      platform,
      goal,
      tone,
    });

    return NextResponse.json({ report });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Unable to analyze this post.";

    console.error("Post Doctor analysis failed:", error);

    if (message.includes("OPENAI_API_KEY")) {
      return NextResponse.json(
        { error: "Post Doctor AI is not configured yet. Add OPENAI_API_KEY to .env.local." },
        { status: 503 }
      );
    }

    if (process.env.NODE_ENV !== "production") {
      return NextResponse.json(
        { error: `Post Doctor dev error: ${message}` },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: "Post Doctor could not analyze this post. Please try again." },
      { status: 500 }
    );
  }
}
