# Post Doctor v4 — Live Image Analysis

This build adds real image analysis to Post Doctor.

## New in v4

- Upload JPG, PNG, or WEBP images
- 8 MB client + server file-size limit
- Optional description alongside an uploaded image
- Image is sent directly to the AI request as a base64 data URL
- No image is saved to disk or database by this app
- Same Post Doctor report for image and description workflows
- Description-only workflow remains supported
- Visual-alignment scoring now uses the actual uploaded image when present

## Apply in Codespaces

Commit the working v3 checkpoint first:

```bash
git add .
git commit -m "Working Post Doctor description AI"
git push
```

Then upload this zip into the repository root and run:

```bash
unzip -o post-doctor-website-v4-image-ai.zip
npm install
npm run dev
```

Your existing `.env.local` should remain in place.

## Test

### Image only
1. Choose Upload image
2. Pick a JPG/PNG/WEBP under 8 MB
3. Select platform, goal, and tone
4. Click Examine my post

### Image + context
After choosing the photo, add something such as:

```text
This is my first car and I want the post to feel proud without sounding show-offy.
```

Then analyze it.

### Description only
Switch to Describe post and use the existing text workflow.

## Privacy behavior

The app does not persist uploaded images. The browser sends the selected file to
the Next.js route, the route converts it to a base64 data URL in memory, sends
it to the AI request, and returns the report.

## Next suggested build

After image analysis is stable:
- proper Privacy and Terms pages
- lightweight anonymous usage/rate limiting
- production-safe errors
- deploy preview
- PWA icons/install polish
