import { NextResponse } from "next/server";
import { analyzePost } from "@/lib/ai/analyzePost";

export const runtime = "nodejs";

const PLATFORMS = ["Instagram", "TikTok", "Facebook", "X", "LinkedIn", "Pinterest"];
const GOALS = ["More followers", "More views", "More comments", "Build my brand", "Sell something"];
const TONES = ["Casual", "Bold", "Professional", "Funny", "Inspirational", "Minimal"];

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const description = typeof body.description === "string" ? body.description.trim() : "";
    const platform = body.platform;
    const goal = body.goal;
    const tone = body.tone;

    if (
      description.length < 8 ||
      description.length > 700 ||
      !PLATFORMS.includes(platform) ||
      !GOALS.includes(goal) ||
      !TONES.includes(tone)
    ) {
      return NextResponse.json(
        { error: "Please check your post description and selections." },
        { status: 400 }
      );
    }

    const report = await analyzePost({ description, platform, goal, tone });
    return NextResponse.json({ report });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Unable to analyze this post.";

    console.error("Post Doctor analysis failed:", error);

    if (message.includes("OPENAI_API_KEY")) {
      return NextResponse.json(
        { error: "Post Doctor AI is not configured yet. Add OPENAI_API_KEY to .env.local." },
        { status: 503 }
      );
    }

    // Helpful while developing in Codespaces; do not expose raw provider errors in production.
    if (process.env.NODE_ENV !== "production") {
      return NextResponse.json(
        { error: `Post Doctor dev error: ${message}` },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: "Post Doctor could not analyze this post. Please try again." },
      { status: 500 }
    );
  }
}
