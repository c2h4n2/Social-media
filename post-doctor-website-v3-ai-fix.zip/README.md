# Post Doctor v3 AI — Fix Pack

This patch simplifies the AI output path and exposes development errors in the UI.

## Why this patch exists

The prior build used `responses.parse()` + `zodTextFormat()`. OpenAI's Node SDK
has had version-specific compatibility issues around Zod helpers. This version
uses the regular Responses API, asks for JSON, validates it ourselves, and shows
the real server error while running in development.

## Apply

From the repository root:

```bash
git add .
git commit -m "Before Post Doctor AI fix"
unzip -o post-doctor-website-v3-ai-fix.zip
npm install
```

Confirm `.env.local` exists:

```bash
cat .env.local
```

It should look like:

```env
OPENAI_API_KEY=YOUR_REAL_KEY
OPENAI_MODEL=gpt-5.4-mini
```

Then restart the dev server completely:

```bash
# press Ctrl+C if npm run dev is still running
npm run dev
```

Try "Describe post" again.

If it fails, the page should now show a message beginning with:

`Post Doctor dev error: ...`

That exact message will tell us whether the issue is API key, model access,
billing/quota, malformed model output, or something else.
