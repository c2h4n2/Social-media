import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import { z } from "zod";
import type { PostDoctorReport } from "@/lib/post-doctor";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const ReportSchema = z.object({
  summary: z.string(),
  captions: z.array(z.string()).length(3),
  hook: z.string(),
  cta: z.string(),
  keywords: z.array(z.string()).min(4).max(10),
  hashtags: z.array(z.string()).min(4).max(10),
  strengths: z.array(z.string()).min(2).max(4),
  improvements: z.array(z.string()).min(2).max(4),
  scores: z.object({
    hook: z.number().int().min(0).max(20),
    caption: z.number().int().min(0).max(20),
    platformFit: z.number().int().min(0).max(15),
    cta: z.number().int().min(0).max(15),
    engagement: z.number().int().min(0).max(15),
    visualAlignment: z.number().int().min(0).max(15),
    total: z.number().int().min(0).max(100),
  }),
});

type AnalyzePostInput = {
  description: string;
  platform: string;
  goal: string;
  tone: string;
};

const SYSTEM_PROMPT = `
You are Post Doctor, an expert social-media content editor.

Your job is to improve a user's planned social post before it is published.
Be practical, specific, natural, and platform-aware. Do not promise virality,
followers, reach, sales, or algorithmic outcomes.

Return exactly three substantially different caption options. Captions should
sound human and fit the requested tone. Avoid generic AI filler and unnecessary
emoji. Make the hook usable as an opening line. Make the CTA easy for a real
person to respond to.

Hashtags and keywords should be relevant rather than stuffed. Do not invent
facts about the user's image or situation that are not in the description.

Scoring:
- hook: 0-20
- caption: 0-20
- platformFit: 0-15
- cta: 0-15
- engagement: 0-15
- visualAlignment: 0-15
- total: sum of the six categories, 0-100

Because this request is description-only, visualAlignment measures how clearly
the described visual and the proposed copy work together, not actual image
quality.

Strengths and improvements must explain the score in concise language.
`;

export async function analyzePost(input: AnalyzePostInput): Promise<PostDoctorReport> {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is not configured.");
  }

  const response = await client.responses.parse({
    model: process.env.OPENAI_MODEL || "gpt-5.6",
    input: [
      {
        role: "system",
        content: SYSTEM_PROMPT,
      },
      {
        role: "user",
        content: [
          `Platform: ${input.platform}`,
          `Goal: ${input.goal}`,
          `Tone: ${input.tone}`,
          "",
          "Planned post:",
          input.description,
        ].join("\n"),
      },
    ],
    text: {
      format: zodTextFormat(ReportSchema, "post_doctor_report"),
    },
  });

  if (!response.output_parsed) {
    throw new Error("The model did not return a Post Doctor report.");
  }

  const report = response.output_parsed;
  const computedTotal =
    report.scores.hook +
    report.scores.caption +
    report.scores.platformFit +
    report.scores.cta +
    report.scores.engagement +
    report.scores.visualAlignment;

  return {
    ...report,
    scores: {
      ...report.scores,
      total: computedTotal,
    },
  };
}
