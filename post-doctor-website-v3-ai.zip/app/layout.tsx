import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Post Doctor",
  description: "Improve your social media post before you publish it.",
  applicationName: "Post Doctor",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Post Doctor"
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
