"use client";

import { ChangeEvent, useMemo, useRef, useState } from "react";
import type { PostDoctorReport } from "@/lib/post-doctor";

type Platform = "Instagram" | "TikTok" | "Facebook" | "X" | "LinkedIn" | "Pinterest";
type Goal = "More followers" | "More views" | "More comments" | "Build my brand" | "Sell something";
type Tone = "Casual" | "Bold" | "Professional" | "Funny" | "Inspirational" | "Minimal";

const platforms: Platform[] = ["Instagram", "TikTok", "Facebook", "X", "LinkedIn", "Pinterest"];
const goals: Goal[] = ["More followers", "More views", "More comments", "Build my brand", "Sell something"];
const tones: Tone[] = ["Casual", "Bold", "Professional", "Funny", "Inspirational", "Minimal"];

export default function Home() {
  const [mode, setMode] = useState<"upload" | "describe">("describe");
  const [imageName, setImageName] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");
  const [description, setDescription] = useState("");
  const [platform, setPlatform] = useState<Platform>("Instagram");
  const [goal, setGoal] = useState<Goal>("More followers");
  const [tone, setTone] = useState<Tone>("Casual");
  const [report, setReport] = useState<PostDoctorReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState("");
  const [error, setError] = useState("");
  const resultsRef = useRef<HTMLDivElement>(null);

  const ready = useMemo(
    () => mode === "describe" && description.trim().length >= 8,
    [mode, description]
  );

  function handleImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setImageName(file.name);
    setPreviewUrl(URL.createObjectURL(file));
  }

  async function examinePost() {
    if (!ready || loading) return;

    setLoading(true);
    setError("");
    setReport(null);

    try {
      const response = await fetch("/api/analyze-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description, platform, goal, tone }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Unable to analyze your post.");
      }

      setReport(data.report);
      setTimeout(
        () => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
        80
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to analyze your post.");
    } finally {
      setLoading(false);
    }
  }

  async function copyText(label: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      setTimeout(() => setCopied(""), 1400);
    } catch {
      setCopied("");
    }
  }

  function resetAnalyzer() {
    setReport(null);
    setError("");
    setCopied("");
    setImageName("");
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl("");
    setDescription("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const fullPost = report
    ? [report.hook, report.captions[0], report.cta, report.hashtags.join(" ")].join("\n\n")
    : "";

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="Post Doctor home">
          <span className="brandMark">+</span>
          <span>Post Doctor</span>
        </a>
        <span className="beta">BETA</span>
      </header>

      <section className="hero">
        <div className="eyebrow">AI SOCIAL MEDIA ASSISTANT</div>
        <h1>Make your post better <span>before</span> you publish it.</h1>
        <p>
          Describe your planned post and get a tailored caption, hook, CTA,
          keywords and audience-growth suggestions.
        </p>
      </section>

      <section className="card analyzerCard">
        <div className="modeTabs" role="tablist">
          <button
            className={mode === "upload" ? "tab active" : "tab"}
            onClick={() => { setMode("upload"); setError(""); }}
            type="button"
          >
            Upload image
            <small className="comingSoon">NEXT</small>
          </button>
          <button
            className={mode === "describe" ? "tab active" : "tab"}
            onClick={() => { setMode("describe"); setError(""); }}
            type="button"
          >
            Describe post
          </button>
        </div>

        {mode === "upload" ? (
          <>
            <label className={previewUrl ? "uploadZone hasImage" : "uploadZone"}>
              {previewUrl ? (
                <>
                  <img src={previewUrl} alt="Selected post preview" />
                  <div className="uploadOverlay">
                    <strong>Image selected</strong>
                    <span>{imageName}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="uploadIcon">↥</div>
                  <strong>Choose a photo</strong>
                  <span>JPG, PNG or WEBP</span>
                </>
              )}
              <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleImage} />
            </label>
            <div className="featureNotice">
              <strong>Image analysis is the next build.</strong>
              <span>
                The upload preview is ready. Switch to “Describe post” to test the live AI analyzer now.
              </span>
            </div>
          </>
        ) : (
          <div className="fieldBlock">
            <label htmlFor="description">What are you planning to post?</label>
            <textarea
              id="description"
              rows={6}
              maxLength={700}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Example: A photo of my black Mustang at sunset. It's my first car and I want the post to feel proud and confident without sounding show-offy."
            />
            <span className="counter">{description.length}/700</span>
          </div>
        )}

        <div className="selectorGrid">
          <SelectField label="Platform" value={platform} onChange={(v) => setPlatform(v as Platform)} options={platforms} />
          <SelectField label="Goal" value={goal} onChange={(v) => setGoal(v as Goal)} options={goals} />
          <SelectField label="Tone" value={tone} onChange={(v) => setTone(v as Tone)} options={tones} />
        </div>

        <button className="primaryButton" type="button" onClick={examinePost} disabled={!ready || loading}>
          <span className="stethoscope">⌁</span>
          {loading ? "Examining your post..." : "Examine my post"}
        </button>

        {mode === "describe" && !ready && !loading && (
          <p className="helper">Add a short description to continue.</p>
        )}

        {error && <div className="errorBox" role="alert">{error}</div>}
      </section>

      {loading && (
        <section className="scanCard" aria-live="polite">
          <div className="scanPulse" />
          <div>
            <strong>Post Doctor is examining your post</strong>
            <span>Checking hook, caption, platform fit and engagement opportunities…</span>
          </div>
        </section>
      )}

      <section className="trustRow">
        <div><strong>Specific</strong><span>Advice tailored to your platform and goal</span></div>
        <div><strong>Creator-first</strong><span>Natural copy instead of generic filler</span></div>
        <div><strong>Mobile-ready</strong><span>Designed for creators on phones</span></div>
      </section>

      {report && (
        <section className="results" ref={resultsRef}>
          <div className="resultsHeader">
            <div>
              <div className="eyebrow">POST DOCTOR REPORT</div>
              <h2>{report.summary}</h2>
              <p>Tailored for {platform} · {goal} · {tone}</p>
            </div>
            <ScoreRing score={report.scores.total} />
          </div>

          <ScoreBreakdown scores={report.scores} />

          <div className="resultsGrid">
            <ResultCard title="Caption options" wide>
              {report.captions.map((caption, index) => (
                <CaptionOption
                  key={caption}
                  number={String(index + 1)}
                  value={caption}
                  copied={copied}
                  onCopy={copyText}
                />
              ))}
            </ResultCard>

            <ResultCard title="Hook">
              <p className="bigCopy">“{report.hook}”</p>
            </ResultCard>

            <ResultCard title="Call to action">
              <p className="bigCopy">“{report.cta}”</p>
            </ResultCard>

            <ResultCard title="Keywords & hashtags" wide>
              <div className="chips">
                {[...report.keywords, ...report.hashtags].map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
            </ResultCard>

            <ResultCard title="Doctor's notes" wide>
              <ul className="notes">
                {report.strengths.map((note) => (
                  <li key={note}><span>✓</span>{note}</li>
                ))}
                {report.improvements.map((note) => (
                  <li key={note} className="improvement"><span>!</span>{note}</li>
                ))}
              </ul>
            </ResultCard>
          </div>

          <div className="resultActions">
            <button
              className="primaryButton"
              type="button"
              onClick={() => copyText("complete", fullPost)}
            >
              {copied === "complete" ? "Copied!" : "Copy complete post"}
            </button>
            <button className="secondaryButton" type="button" onClick={resetAnalyzer}>
              Analyze another
            </button>
          </div>

          <p className="disclaimer">
            Post Doctor scores and suggestions are AI-generated content-quality estimates,
            not predictions of reach, engagement or virality.
          </p>
        </section>
      )}

      <footer>
        <span>© 2026 Post Doctor</span>
        <nav>
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
        </nav>
      </footer>
    </main>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: readonly string[];
}) {
  return (
    <label className="selectField">
      <span>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((option) => <option key={option}>{option}</option>)}
      </select>
    </label>
  );
}

function ResultCard({
  title,
  children,
  wide = false,
}: {
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <article className={wide ? "resultCard wide" : "resultCard"}>
      <h3>{title}</h3>
      {children}
    </article>
  );
}

function CaptionOption({
  number,
  value,
  copied,
  onCopy,
}: {
  number: string;
  value: string;
  copied: string;
  onCopy: (label: string, value: string) => void;
}) {
  const key = `caption-${number}`;
  return (
    <div className="captionOption">
      <span className="captionNumber">{number}</span>
      <p>{value}</p>
      <button type="button" onClick={() => onCopy(key, value)}>
        {copied === key ? "Copied!" : "Copy"}
      </button>
    </div>
  );
}

function ScoreRing({ score }: { score: number }) {
  const degrees = Math.max(0, Math.min(100, score)) * 3.6;
  return (
    <div
      className="scoreRing"
      style={{
        background: `radial-gradient(circle at center, white 60%, transparent 61%), conic-gradient(var(--accent) 0deg ${degrees}deg, #e8e8ef ${degrees}deg 360deg)`
      }}
      aria-label={`Post score ${score} out of 100`}
    >
      <strong>{score}</strong>
      <span>/ 100</span>
    </div>
  );
}

function ScoreBreakdown({ scores }: { scores: PostDoctorReport["scores"] }) {
  const items = [
    ["Hook", scores.hook, 20],
    ["Caption", scores.caption, 20],
    ["Platform fit", scores.platformFit, 15],
    ["CTA", scores.cta, 15],
    ["Engagement", scores.engagement, 15],
    ["Post alignment", scores.visualAlignment, 15],
  ] as const;

  return (
    <div className="scoreBreakdown">
      {items.map(([label, value, max]) => (
        <div className="scoreItem" key={label}>
          <div><span>{label}</span><strong>{value}/{max}</strong></div>
          <div className="scoreTrack">
            <span style={{ width: `${(value / max) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}
