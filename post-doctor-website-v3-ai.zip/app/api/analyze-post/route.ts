import { NextResponse } from "next/server";
import { z } from "zod";
import { analyzePost } from "@/lib/ai/analyzePost";

export const runtime = "nodejs";

const RequestSchema = z.object({
  description: z.string().trim().min(8).max(700),
  platform: z.enum(["Instagram", "TikTok", "Facebook", "X", "LinkedIn", "Pinterest"]),
  goal: z.enum([
    "More followers",
    "More views",
    "More comments",
    "Build my brand",
    "Sell something",
  ]),
  tone: z.enum([
    "Casual",
    "Bold",
    "Professional",
    "Funny",
    "Inspirational",
    "Minimal",
  ]),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const input = RequestSchema.parse(body);
    const report = await analyzePost(input);

    return NextResponse.json({ report });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Please check your post description and selections." },
        { status: 400 }
      );
    }

    const message =
      error instanceof Error ? error.message : "Unable to analyze this post.";

    console.error("Post Doctor analysis failed:", message);

    if (message.includes("OPENAI_API_KEY")) {
      return NextResponse.json(
        { error: "Post Doctor AI is not configured yet. Add OPENAI_API_KEY to .env.local." },
        { status: 503 }
      );
    }

    return NextResponse.json(
      { error: "Post Doctor could not analyze this post. Please try again." },
      { status: 500 }
    );
  }
}
