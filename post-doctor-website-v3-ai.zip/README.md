# Post Doctor v3 — Live Description AI

This build replaces the mock description report with a real OpenAI-powered
Post Doctor analysis.

## New in v3

- Real `/api/analyze-post` route
- OpenAI Responses API
- Zod structured output
- Real captions, hook, CTA, keywords, hashtags, notes, and scoring
- Score breakdown
- API and UI error states
- API key remains server-side
- Upload UI retained for the next image-analysis build

## 1. Apply the package

Commit your current version first:

```bash
git add .
git commit -m "Post Doctor website v2"
```

Extract this package over the repository root and install:

```bash
unzip -o post-doctor-website-v3-ai.zip
npm install
```

## 2. Add the API key

Create `.env.local` in the repository root:

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
OPENAI_API_KEY=YOUR_REAL_KEY_HERE
OPENAI_MODEL=gpt-5.6
```

Do not commit `.env.local`.

## 3. Start the app

```bash
npm run dev
```

Open the site, choose **Describe post**, enter a description, and press
**Examine my post**.

## Expected structure

```text
app/
  api/
    analyze-post/
      route.ts
  globals.css
  layout.tsx
  manifest.ts
  page.tsx

lib/
  ai/
    analyzePost.ts
  post-doctor.ts

.env.example
package.json
tsconfig.json
```

## Troubleshooting

### "Post Doctor AI is not configured yet"
The server cannot see `OPENAI_API_KEY`. Confirm `.env.local` is at the repository
root and restart `npm run dev`.

### API/model error
Confirm the API key has access to the model configured in `OPENAI_MODEL`.
You can change the model in `.env.local` without changing application code.

## Next build

Image analysis will use the same `/api/analyze-post` concept and the same
structured Post Doctor report, adding the uploaded image as multimodal input.
