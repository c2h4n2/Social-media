# Post Doctor v5 — Public Beta Protection

This build prepares the working Post Doctor MVP for a small public beta.

## New in v5

- 5 analyses/hour lightweight network rate limit
- 429 response with Retry-After
- Hashed network-derived rate-limit keys
- Production-safe error messages
- Request IDs on server errors
- Security headers
- Real Privacy page
- Real Terms page
- SEO metadata
- robots.txt support
- sitemap.xml support
- Usage-remaining indicator in the UI
- Configurable public site URL

## Important limitation

The included rate limiter is intentionally simple and uses process memory.

That is useful for local development, a single long-running Node server, and a
small beta. It is NOT a durable distributed rate limiter across many serverless
instances. Before large-scale public traffic, replace it with a shared store
such as Redis/KV or a platform-native rate-limit product.

## Apply in Codespaces

Commit v4 first:

```bash
git add .
git commit -m "Working Post Doctor image AI"
git push
```

Then:

```bash
unzip -o post-doctor-website-v5-public-beta.zip
npm install
npm run dev
```

Your existing `.env.local` should remain in place.

Add these values to `.env.local`:

```env
NEXT_PUBLIC_SITE_URL=http://localhost:3000
RATE_LIMIT_SALT=use-a-random-secret-here
```

Do not commit `.env.local`.

## Test the usage limit

Run several analyses. The report should show the number remaining.

After the limit is reached, the UI should show:

`You’ve reached the Post Doctor beta limit. Please try again later.`

## Before real deployment

Update:

```env
NEXT_PUBLIC_SITE_URL=https://your-real-domain.com
```

Then restart/redeploy.

## Recommended next milestone

Deploy a private preview and test it on:
- desktop Chrome/Safari
- iPhone Safari
- Android Chrome

After that:
- durable production rate limiting
- analytics
- accounts/free tier
- monetization
