# Post Doctor Website v2

Website-first prototype update.

## What changed
- Loading/examining state
- Working caption copy buttons
- Working "Copy complete post"
- Reset/"Analyze another" flow
- Reduced-motion accessibility support
- Next.js bumped to 15.4.8

## Apply in Codespaces
Back up or commit your current work first, then copy the contents of this package into the repository root.

Run:

```bash
npm install
npm run dev
```

This remains a front-end prototype. AI integration comes after the website UX is approved.
