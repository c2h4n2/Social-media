"use client";

import { ChangeEvent, useMemo, useRef, useState } from "react";

type Platform = "Instagram" | "TikTok" | "Facebook" | "X" | "LinkedIn" | "Pinterest";
type Goal = "More followers" | "More views" | "More comments" | "Build my brand" | "Sell something";
type Tone = "Casual" | "Bold" | "Professional" | "Funny" | "Inspirational" | "Minimal";

const platforms: Platform[] = ["Instagram", "TikTok", "Facebook", "X", "LinkedIn", "Pinterest"];
const goals: Goal[] = ["More followers", "More views", "More comments", "Build my brand", "Sell something"];
const tones: Tone[] = ["Casual", "Bold", "Professional", "Funny", "Inspirational", "Minimal"];

export default function Home() {
  const [mode, setMode] = useState<"upload" | "describe">("upload");
  const [imageName, setImageName] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");
  const [description, setDescription] = useState("");
  const [platform, setPlatform] = useState<Platform>("Instagram");
  const [goal, setGoal] = useState<Goal>("More followers");
  const [tone, setTone] = useState<Tone>("Casual");
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState("");
  const resultsRef = useRef<HTMLDivElement>(null);

  const ready = useMemo(
    () => mode === "upload" ? Boolean(imageName) : description.trim().length >= 8,
    [mode, imageName, description]
  );

  function handleImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    setImageName(file.name);
    setPreviewUrl(URL.createObjectURL(file));
  }

  async function examinePost() {
    if (!ready || loading) return;
    setLoading(true);
    setShowResults(false);
    await new Promise((resolve) => setTimeout(resolve, 900));
    setShowResults(true);
    setLoading(false);
    setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  }

  async function copyText(label: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      setTimeout(() => setCopied(""), 1400);
    } catch {
      setCopied("");
    }
  }

  function resetAnalyzer() {
    setShowResults(false);
    setLoading(false);
    setCopied("");
    setImageName("");
    setPreviewUrl("");
    setDescription("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const fullPost = `You almost scrolled past this.\n\nThe kind of moment you wish you could freeze. What would you caption this?\n\nWhat would you do differently?\n\n#creator #socialmedia #contentideas #instagramtips`;

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="Post Doctor home">
          <span className="brandMark">+</span>
          <span>Post Doctor</span>
        </a>
        <span className="beta">BETA</span>
      </header>

      <section className="hero">
        <div className="eyebrow">AI SOCIAL MEDIA ASSISTANT</div>
        <h1>Make your post better <span>before</span> you publish it.</h1>
        <p>
          Upload your photo or describe your post. Post Doctor gives you captions,
          hooks, CTAs and audience-growth suggestions.
        </p>
      </section>

      <section className="card analyzerCard">
        <div className="modeTabs" role="tablist">
          <button
            className={mode === "upload" ? "tab active" : "tab"}
            onClick={() => setMode("upload")}
            type="button"
          >
            Upload image
          </button>
          <button
            className={mode === "describe" ? "tab active" : "tab"}
            onClick={() => setMode("describe")}
            type="button"
          >
            Describe post
          </button>
        </div>

        {mode === "upload" ? (
          <label className={previewUrl ? "uploadZone hasImage" : "uploadZone"}>
            {previewUrl ? (
              <>
                <img src={previewUrl} alt="Selected post preview" />
                <div className="uploadOverlay">
                  <strong>Change image</strong>
                  <span>{imageName}</span>
                </div>
              </>
            ) : (
              <>
                <div className="uploadIcon">↥</div>
                <strong>Choose a photo</strong>
                <span>JPG, PNG or WEBP</span>
              </>
            )}
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleImage} />
          </label>
        ) : (
          <div className="fieldBlock">
            <label htmlFor="description">What are you planning to post?</label>
            <textarea
              id="description"
              rows={6}
              maxLength={700}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Example: A photo of my black Mustang at sunset. I want the post to feel confident but not show-offy."
            />
            <span className="counter">{description.length}/700</span>
          </div>
        )}

        <div className="selectorGrid">
          <SelectField label="Platform" value={platform} onChange={(v) => setPlatform(v as Platform)} options={platforms} />
          <SelectField label="Goal" value={goal} onChange={(v) => setGoal(v as Goal)} options={goals} />
          <SelectField label="Tone" value={tone} onChange={(v) => setTone(v as Tone)} options={tones} />
        </div>

        <button className="primaryButton" type="button" onClick={examinePost} disabled={!ready || loading}>
          <span className="stethoscope">⌁</span>
          {loading ? "Examining your post..." : "Examine my post"}
        </button>

        {!ready && (
          <p className="helper">
            {mode === "upload" ? "Choose an image to continue." : "Add a short description to continue."}
          </p>
        )}
      </section>

      {loading && (
        <section className="scanCard" aria-live="polite">
          <div className="scanPulse" />
          <div>
            <strong>Post Doctor is examining your post</strong>
            <span>Checking hook, caption, platform fit and engagement opportunities…</span>
          </div>
        </section>
      )}

      <section className="trustRow">
        <div><strong>Fast</strong><span>One simple workflow</span></div>
        <div><strong>Private-first</strong><span>No permanent image storage planned</span></div>
        <div><strong>Mobile-ready</strong><span>Designed for creators on phones</span></div>
      </section>

      {showResults && (
        <section className="results" ref={resultsRef}>
          <div className="resultsHeader">
            <div>
              <div className="eyebrow">POST DOCTOR REPORT</div>
              <h2>Your post has strong potential.</h2>
              <p>Mock results for the website prototype. AI analysis comes next.</p>
            </div>
            <ScoreRing score={84} />
          </div>

          <div className="resultsGrid">
            <ResultCard title="Caption options" wide>
              <CaptionOption
                number="1"
                value="The kind of moment you wish you could freeze. What would you caption this?"
                copied={copied}
                onCopy={copyText}
              />
              <CaptionOption
                number="2"
                value="Some posts don't need a long story. Just the right moment."
                copied={copied}
                onCopy={copyText}
              />
              <CaptionOption
                number="3"
                value="New memory unlocked. ✨"
                copied={copied}
                onCopy={copyText}
              />
            </ResultCard>

            <ResultCard title="Hook">
              <p className="bigCopy">“You almost scrolled past this.”</p>
            </ResultCard>

            <ResultCard title="Call to action">
              <p className="bigCopy">“What would you do differently?”</p>
            </ResultCard>

            <ResultCard title="Keywords & hashtags" wide>
              <div className="chips">
                {["#creator", "#socialmedia", "#contentideas", "#instagramtips", "audience growth", "visual storytelling"].map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
            </ResultCard>

            <ResultCard title="Doctor's notes" wide>
              <ul className="notes">
                <li><span>✓</span> Strong visual concept for {platform}.</li>
                <li><span>✓</span> Tone fits your goal: {goal.toLowerCase()}.</li>
                <li><span>!</span> Lead with curiosity instead of describing the image.</li>
                <li><span>!</span> Add a question that is easy to answer in one sentence.</li>
              </ul>
            </ResultCard>
          </div>

          <div className="resultActions">
            <button
              className="primaryButton"
              type="button"
              onClick={() => copyText("complete", fullPost)}
            >
              {copied === "complete" ? "Copied!" : "Copy complete post"}
            </button>
            <button className="secondaryButton" type="button" onClick={resetAnalyzer}>Analyze another</button>
          </div>

          <p className="disclaimer">
            Post Doctor scores and suggestions are content-quality estimates, not predictions of reach, engagement or virality.
          </p>
        </section>
      )}

      <footer>
        <span>© 2026 Post Doctor</span>
        <nav>
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
        </nav>
      </footer>
    </main>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: readonly string[];
}) {
  return (
    <label className="selectField">
      <span>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((option) => <option key={option}>{option}</option>)}
      </select>
    </label>
  );
}

function ResultCard({
  title,
  children,
  wide = false,
}: {
  title: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <article className={wide ? "resultCard wide" : "resultCard"}>
      <h3>{title}</h3>
      {children}
    </article>
  );
}

function CaptionOption({
  number,
  value,
  copied,
  onCopy,
}: {
  number: string;
  value: string;
  copied: string;
  onCopy: (label: string, value: string) => void;
}) {
  const key = `caption-${number}`;

  return (
    <div className="captionOption">
      <span className="captionNumber">{number}</span>
      <p>{value}</p>
      <button type="button" onClick={() => onCopy(key, value)}>
        {copied === key ? "Copied!" : "Copy"}
      </button>
    </div>
  );
}

function ScoreRing({ score }: { score: number }) {
  return (
    <div className="scoreRing" aria-label={`Post score ${score} out of 100`}>
      <strong>{score}</strong>
      <span>/ 100</span>
    </div>
  );
}
